import { useState } from 'react';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_COMMENT = 200;

export default function FeedbackForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [rating, setRating] = useState('');
  const [comment, setComment] = useState('');
  const [attempted, setAttempted] = useState(false);
  const [submittedName, setSubmittedName] = useState(null);

  // Errors are derived from current values, so they disappear as soon as a field becomes valid.
  const errors = {
    name: name.trim() === '' ? 'Name is required' : '',
    email: !EMAIL_RE.test(email.trim()) ? 'Enter a valid email address' : '',
    rating: rating === '' ? 'Select a rating' : '',
  };
  const hasErrors = Object.values(errors).some(Boolean);

  const handleSubmit = (e) => {
    e.preventDefault();
    setAttempted(true);
    setSubmittedName(null);
    if (hasErrors) return;

    setSubmittedName(name.trim());
    setName('');
    setEmail('');
    setRating('');
    setComment('');
    setAttempted(false);
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div>
        <label htmlFor="name">Name</label>
        <input
          id="name"
          type="text"
          data-testid="name-input"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        {attempted && errors.name && (
          <p role="alert" data-testid="name-error">{errors.name}</p>
        )}
      </div>

      <div>
        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          data-testid="email-input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {attempted && errors.email && (
          <p role="alert" data-testid="email-error">{errors.email}</p>
        )}
      </div>

      <div>
        <label htmlFor="rating">Rating</label>
        <select
          id="rating"
          data-testid="rating-select"
          value={rating}
          onChange={(e) => setRating(e.target.value)}
        >
          <option value=""></option>
          {[1, 2, 3, 4, 5].map((n) => (
            <option key={n} value={String(n)}>{n}</option>
          ))}
        </select>
        {attempted && errors.rating && (
          <p role="alert" data-testid="rating-error">{errors.rating}</p>
        )}
      </div>

      <div>
        <label htmlFor="comment">Comment</label>
        <textarea
          id="comment"
          data-testid="comment-input"
          maxLength={MAX_COMMENT}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <span data-testid="comment-count">{`${comment.length}/${MAX_COMMENT}`}</span>
      </div>

      <button type="submit" data-testid="submit-btn">Submit feedback</button>

      {submittedName !== null && (
        <p role="status" data-testid="success-msg">
          {`Thank you, ${submittedName}! Feedback submitted.`}
        </p>
      )}
    </form>
  );
}
