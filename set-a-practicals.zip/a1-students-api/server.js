const express = require('express');

const app = express();
app.use(express.json());

let students = [];
let nextId = 1; // only ever increases, so deleted IDs are never reused

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValid(body) {
  return (
    body !== null &&
    typeof body === 'object' &&
    typeof body.name === 'string' && body.name.trim() !== '' &&
    typeof body.email === 'string' && EMAIL_RE.test(body.email.trim()) &&
    Number.isInteger(body.age) && body.age > 0
  );
}

function findIndexById(rawId) {
  if (!/^\d+$/.test(rawId)) return -1;
  const id = Number(rawId);
  return students.findIndex((s) => s.id === id);
}

// Create
app.post('/students', (req, res) => {
  if (!isValid(req.body)) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  const name = req.body.name.trim();
  const email = req.body.email.trim();
  const { age } = req.body;

  const exists = students.some((s) => s.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return res.status(409).json({ error: 'Email already exists' });
  }

  const student = { id: nextId++, name, email, age };
  students.push(student);
  res.status(201).json(student);
});

// List (optional ?minAge=)
app.get('/students', (req, res) => {
  if (req.query.minAge !== undefined) {
    const minAge = Number(req.query.minAge);
    if (req.query.minAge === '' || Number.isNaN(minAge)) {
      return res.status(400).json({ error: 'Invalid input' });
    }
    return res.status(200).json(students.filter((s) => s.age >= minAge));
  }
  res.status(200).json(students);
});

// Fetch one
app.get('/students/:id', (req, res) => {
  const i = findIndexById(req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Student not found' });
  res.status(200).json(students[i]);
});

// Delete
app.delete('/students/:id', (req, res) => {
  const i = findIndexById(req.params.id);
  if (i === -1) return res.status(404).json({ error: 'Student not found' });
  students.splice(i, 1);
  res.status(204).end();
});

// Malformed JSON body -> 400
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid input' });
  }
  next(err);
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Listening on ${PORT}`));
}
